package blueOrigin;

import org.junit.Assert;
import org.junit.Test;

public class SpaceshipTests {

    //1.Трябва да си тествам конструктора
    //1.2 сетНаме
    //1.3 сетCapacity
    //1.4 правилно създаден констуктор

    @Test(expected = NullPointerException.class)
    public void testSetNameThrowsNullException(){
        Spaceship spaceship=new Spaceship(null,3);
    }
    @Test(expected = NullPointerException.class)
    public void testSetNameThrowsException(){
        Spaceship spaceship=new Spaceship("",3);
    }
    @Test(expected = IllegalArgumentException.class)
    public void testCapacitiThrowsException(){
        Spaceship spaceship=new Spaceship("Nicolas",-1);
    }
}
