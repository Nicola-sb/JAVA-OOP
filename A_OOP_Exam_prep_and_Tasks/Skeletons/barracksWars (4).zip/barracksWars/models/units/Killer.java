package barracksWars.models.units;

public class Killer extends AbstractUnit{

    public Killer() {
        super(10, 10);
    }
}
